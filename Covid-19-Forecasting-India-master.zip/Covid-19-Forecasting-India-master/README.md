# Covid-19-Forecasting-India
A time series analysis on the daily cases of Covid -19 in India

This is a simple ongoing Analysis on covid-19 crisis.

This Analysis is on forecasting the Daily New Cases of Covid 19 from 28th April till the next 14 days in India.

